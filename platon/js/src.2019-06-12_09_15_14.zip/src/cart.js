(function ($) {

    Drupal.behaviors.dcsp_platon = {
      attach: function (context, settings) {


                //replace name table
            //var tableInp = document.querySelector('.views-field-edit-delete');
            //tableInp.innerHTML = `REM`;

                //insert value `-`
            //var inp = document.querySelector('.delete-line-item');
            //inp.value = `-`;


            //     //insert value `Next step`
            // var inpNext = document.querySelector('#site-content-mv #edit-continue');
            // if (inpNext) {
            // inpNext.value = `Next step`;
            //   }


              // //color white `Go back` ПРОВЕРИТЬ НА САФАРИ
              // var editBack = document.querySelector('#site-content-mv #edit-back');
              // if (editBack) {
              //   editBack.style.color = `white`;
              //   }





            //button PREV
            var edit_back = document.querySelector('#site-content-mv .quiz-question-navigation-wrapper #edit-back');
            if (edit_back) {
              edit_back.value = 'Prev';
              }

            // //button NEXT
            var edit_submit = document.querySelector('#site-content-mv .quiz-question-navigation-wrapper #edit-submit');
            if (edit_submit) {
              edit_submit.value = 'Next';
              }

            //button skip
            var edit_submit_hidden = document.querySelector('#site-content-mv .quiz-question-navigation-wrapper #edit-submit-hidden');
            if (edit_submit_hidden) {
              edit_submit_hidden.value = 'Skip';
              }
              
            
            
        }
}

}
)(jQuery)
